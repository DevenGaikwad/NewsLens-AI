# NewsLens Synthetic Article Benchmark v1.0.0

## Purpose

This package is an independently authored educational synthetic benchmark for
classifying fictional articles as **synthetic ledger-consistent** (`1`) or
**synthetic ledger-contradicting** (`0`).  These labels apply only inside the
package's fictional reference world.  They are not findings about real people,
organisations, locations, or events.

The benchmark is intended to demonstrate deterministic data generation,
grouped splitting, lightweight text classification, calibration, abstention,
and transparent limitations.  It is not a professional fact-checking source,
does not retrieve live evidence, and does not establish real-world
misinformation-detection performance.

## Composition

- Dataset identity: `newslens-synthetic-articles-v1.0.0`
- Generator version: `1.0.0`
- Seed: `20260916`
- Fictional event ledgers: 12,000
- Articles: 24,000
- Labels: one ledger-consistent and one ledger-contradicting article per event
- Topics: 12 neutral administrative and community subjects
- Article length contract: 180-550 words

## Grouped splits

| Split | Articles |
|---|---:|
| Training | 18,000 |
| Model validation | 2,400 |
| Calibration | 1,200 |
| Abstention-policy selection | 1,200 |
| Final test | 1,200 |

Paired articles from one event always remain in the same split.  The final test
is reserved for one locked evaluation after model, calibration, and threshold
decisions are complete.

## Generation

The package is generated without an external generative-AI API, paid service,
web scraping, or external dataset rows.  Project-authored fictional entity
lexicons, event ledgers, sentence components, structures, and mutation rules
produce both variants independently.  Both labels use the same fact fields,
template families, and punctuation conventions.  Contradicting variants alter
two to four material event facts.  Generation-only ledgers remain in
`events.jsonl`; model-visible inputs are title and article text.

Each article includes a structured `Reference note` and `Article account`.
Their eleven field values are displayed as stable ten-digit numeric codes,
while the surrounding narrative remains human-readable.  Matching codes mean
that the account agrees with the fictional ledger for that field; different
codes mark the controlled disagreement.  The codes are derived only from the
project-authored fictional values, are checked for collisions, and are mapped
to a neutral numeric token by model-text normalisation.  This prevents a raw
bag-of-words model from exploiting repeated names or status words while still
allowing a transparent, label-independent field comparison.

## Quality controls

The machine-readable `quality_audit.json` records schema, balance, duplicate,
group leakage, near-duplicate, forbidden-term, deny-list, distribution, and
metadata-only predictability checks.  Exact and normalized duplicate counts
must be zero, and event/content overlap across splits must be zero.

The fixed raw-text leakage ceiling is 0.75 balanced accuracy.  The packaged
audit records 0.480864;
the metadata-only baseline records
0.509053.

The structured reference/account fields support transparent consistency
signals.  This benchmark-specific structure is a limitation: performance does
not imply that the same classifier can verify an arbitrary real-world article.

## Responsible use

- Do not describe label `1` as objectively true or label `0` as objectively false.
- Do not use the benchmark as evidence about any real person or organisation.
- Do not treat model confidence as the probability that a real-world claim is true.
- Check important claims against authoritative sources and qualified reviewers.
- Report weak or failed counterfactual performance rather than hiding it.

## Licence and attribution

The dataset contents are offered under CC BY 4.0 to the extent applicable
rights subsist.  Attribute: **NewsLens Synthetic Article Benchmark v1.0.0,
Deven Sachin Gaikwad (2026)**.  See `LICENSE.txt`.  The licence does not remove
all legal, ethical, or suitability risk.
